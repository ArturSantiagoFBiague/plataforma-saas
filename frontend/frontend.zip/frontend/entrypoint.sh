#!/bin/sh

echo "Iniciando Frontend React com Vite..."
npm run dev
