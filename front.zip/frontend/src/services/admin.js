import api from './api';

export const getAdminData = async () => {
  const response = await api.get('/admin/users');
  return response.data;
};

// Função para excluir um usuário
export const deleteUser = async (userId) => {
  try {
    const response = await fetch(`/api/users/${userId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Falha ao excluir o usuário');
    }

    return response.json(); // Supondo que a resposta seja JSON
  } catch (error) {
    console.error('Erro ao excluir usuário:', error);
    throw error;
  }
};
