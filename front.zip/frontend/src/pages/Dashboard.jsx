// src/pages/Dashboard.jsx
import { useAuth } from "../contexts/AuthContext";
import Header from "../components/Header";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleRedirect = () => {
    navigate("/video-wall");
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">Verificando sessão...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="flex flex-col items-center justify-center h-full p-6">
        <h2 className="text-2xl font-bold mb-2">Bem-vindo, {user.name}!</h2>
        <p className="text-gray-600 mb-6">Você está autenticado com sucesso. 🎉</p>
        <button
          onClick={handleRedirect}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
        >
          Ir para o Video Wall
        </button>
      </main>
    </div>
  );
}
